export default {
  productsPerPage: 6,
  dashboardEnabled: true
};

